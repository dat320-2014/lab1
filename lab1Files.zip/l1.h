
double tab_sort_sum(double* tab, int tab_size);

double int dblCmp( const void* item1, const void* item2);
