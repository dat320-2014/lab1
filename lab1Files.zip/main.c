#include <stdio.h>
#include <stdlib.h>
#define TAB_SIZE 5;

double tab_sort_sum( double* tab, int tab_size);

void main(int argc, char*argv[])
{
	int i;
	double tab[5]={4.3, 2.3, 5.4, 1.2, 1.3};
	double sum;
	sum=tab_sort_sum(tab, 5);
	for(i=0;i<5;i++)
	{
		printf("sum%f\n", i, tab[i]);
	}
}

