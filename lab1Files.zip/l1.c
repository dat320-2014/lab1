
static int dblCmp( const void* item1, const void* item2);

double tab_sort_sum(double* tab, int tab_size)
{
	int i;
	double sum = 0;
	qsort(tab,tab_size, sizeof(double), dblCmp);
	for( i=0; i<tab_size; i++)
	{
		sum = sum + tab[i];
	}

	return sum;

}

static int dblCmp( const void* item1, const void* item2)
{
	if(*(double *)item1 < (double *)item2){ return -1;}
	if(*(double *)item1 ==  (double *)item2){ return 0;}
	if(*(double *)item1 > (double *)item2){ return 1;}
}
